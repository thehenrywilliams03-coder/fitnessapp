// ============================================================
//  AryanFitTrack — Cloudflare Worker Proxy
//  Ye file Cloudflare Workers pe deploy hoti hai.
//  API key yahan SECRET ke roop mein store hoti hai —
//  kisi ko bhi HTML mein nahi dikhti.
// ============================================================

export default {
  async fetch(request, env) {

    // ── CORS preflight ──
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type',
        },
      });
    }

    // ── Only POST allowed ──
    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405 });
    }

    // ── Rate limit check (optional basic protection) ──
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';

    // ── Forward to Anthropic ──
    try {
      const body = await request.text();

      const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': env.ANTHROPIC_API_KEY,          // ← Secret stored in Cloudflare
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: body,
      });

      const responseText = await anthropicRes.text();

      return new Response(responseText, {
        status: anthropicRes.status,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',           // ← Allows any domain (your HTML file)
        },
      });

    } catch (err) {
      return new Response(
        JSON.stringify({ error: 'Worker error: ' + err.message }),
        {
          status: 500,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
          },
        }
      );
    }
  },
};
